#include <Windows.h>
#include <iostream>
#include <vector>
#include <functional>

#define JUI_WINDOW_NORMAL 0
#define JUI_WINDOW_FULLSCREEN 1
#define JUI_WINDOW_MINIMIZED 2
#define JUI_WINDOW_STATIC 3
#define JUI_WINDOW_BLANK 4
#define JUI_WINDOW_HIDDEN 5
#define JUI_WINDOW_INVALID 6

#define JUI_ERRORS_NONE 0
#define JUI_ERRORS_ALL 1

#define jui_cb std::function<void(int)>
#define jui_elem int

namespace jui {
    struct jui_color {
        int r;
        int g;
        int b;
        jui_color(int rr, int gg, int bb) {
            r = rr;
            g = gg;
            b = bb;
        }
    };

    struct jui_arg {
        int i;
        const char* s;
    };

    struct jui_instruction {
        int op;
        std::vector<int> args;
    };

    class jui_window {
        public:
            const char* name;

            jui_window(const char* wname, int wtype = JUI_WINDOW_NORMAL, RECT wrect = { 500, 500, 800, 800 }, COLORREF bg = RGB(255, 255, 255), HICON icon = NULL, HCURSOR cursor = LoadCursor(nullptr, IDC_ARROW));
            void deploy();
            void close();

            void strokeRect(int x, int y, int width, int height, jui_color color);
            void fillRect(int x, int y, int width, int height, jui_color color);
            void clear();
            jui_elem button(const char* text, int x, int y, int width, int height);
            void text(const char* v, int x, int y, int size, const char* font);
            jui_elem textbox(const char* pHolder, int x, int y, int width, int height);
            jui_elem dropdown(const char** opts, int oLen, int x, int y, int width, int itmHeight);
            void image(const char* img, int x, int y, int width, int height);
            
            void onEvent(jui_elem e, jui_cb cb, int forceSet = 0);

            char* getTextBoxVal(jui_elem e);
            char* getDropdownVal(jui_elem e);
        private:
            int type;
            HWND hwnd;
            std::vector<jui_instruction> jui_drawbuf;
            RECT rect;
            COLORREF bg;

            std::vector<HWND> buttons;
            std::vector<HWND> textboxes;
            std::vector<HWND> comboboxes;

            static std::vector<jui_cb> eCbs;

            void closeAllWindows();
            static LRESULT __stdcall WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
    };

    void setErrorMode(int mode);
}